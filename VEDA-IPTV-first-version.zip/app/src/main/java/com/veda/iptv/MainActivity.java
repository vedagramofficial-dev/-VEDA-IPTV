package com.veda.iptv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.net.Uri;
import android.content.SharedPreferences;
import java.io.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(16,11,28), PANEL=Color.rgb(31,23,49), PURPLE=Color.rgb(179,136,255), WHITE=Color.rgb(248,246,255);
    private LinearLayout root, channelList, categoryRow;
    private FrameLayout playerFrame;
    private VideoView videoView;
    private TextView status, pageTitle;
    private final ArrayList<Channel> channels=new ArrayList<>();
    private String selectedCategory="Все";
    private boolean tvPage=false;
    static class Channel { String name, category, url; Channel(String n,String c,String u){name=n;category=c;url=u;} }

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN); loadBundledChannels(); loadUserChannels(); showHome();}

    private void loadBundledChannels(){
        try(BufferedReader br=new BufferedReader(new InputStreamReader(getAssets().open("armenian_channels.m3u8"),"UTF-8"))){
            String line,name=null; while((line=br.readLine())!=null){line=line.trim(); if(line.startsWith("#EXTINF")){int comma=line.lastIndexOf(',');name=comma>=0?line.substring(comma+1).trim():"Телеканал";} else if(!line.isEmpty()&&!line.startsWith("#")&&name!=null){if(line.startsWith("http://")||line.startsWith("https://"))channels.add(new Channel(name,categoryFor(name),line));name=null;}}
        }catch(Exception ignored){}
    }
    private String categoryFor(String n){String s=n.toLowerCase(Locale.ROOT);
        if(has(s,"news","news","azatutyun","24 news","lurer","новост"))return "Новости";
        if(has(s,"sport","football","fight","sport","матч"))return "Спорт";
        if(has(s,"music","muz","music","radio","музык"))return "Музыка";
        if(has(s,"kino","cinema","cineman","film","movie","кино","фильм"))return "Фильмы";
        if(has(s,"cartoon","kids","baby","junior","детск","мульт"))return "Детские";
        if(has(s,"h1","armenia tv","atv","shant","kentron","armnews","dar 21","yerkir","hay tv"))return "Армянские";
        return "Армянские";
    }
    private boolean has(String s,String... terms){for(String t:terms)if(s.contains(t))return true;return false;}
    private void loadUserChannels(){SharedPreferences p=getSharedPreferences("user_channels",MODE_PRIVATE);String raw=p.getString("items","");for(String row:raw.split("\\n")){String[] a=row.split("\\|",3);if(a.length==3&&!a[2].trim().isEmpty())channels.add(new Channel(a[0],a[1],a[2]));}}
    private void saveUserChannel(Channel c){SharedPreferences p=getSharedPreferences("user_channels",MODE_PRIVATE);String old=p.getString("items","");p.edit().putString("items",old+(old.isEmpty()?"":"\n")+c.name.replace("|"," ")+"|"+c.category.replace("|"," ")+"|"+c.url).apply();}

    private void showHome(){tvPage=false;root=base();LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(Gravity.CENTER);content.setPadding(dp(22),dp(20),dp(22),dp(20));root.addView(content,new LinearLayout.LayoutParams(-1,0,1));TextView logo=text("VEDA IPTV",30,PURPLE,true);logo.setGravity(Gravity.CENTER);content.addView(logo);TextView sub=text("Армянское телевидение",15,0xFFBDB5CE,false);sub.setGravity(Gravity.CENTER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.bottomMargin=dp(30);content.addView(sub,sp);
        Button tv=bigButton("▶   VEDA TV","Открыть телеканалы");content.addView(tv,buttonLp());tv.setOnClickListener(v->showTv());Button add=bigButton("＋   Добавить канал","Добавить HTTPS-ссылку вручную");LinearLayout.LayoutParams ap=buttonLp();ap.topMargin=dp(14);content.addView(add,ap);add.setOnClickListener(v->addChannelDialog());TextView foot=text("Каналов в каталоге: "+channels.size(),12,0xFF9288A7,false);foot.setGravity(Gravity.CENTER);content.addView(foot);setContentView(root);}

    private void showTv(){tvPage=true;root=base();LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView back=text("‹  Назад",15,WHITE,true);back.setPadding(dp(8),dp(10),dp(14),dp(10));back.setOnClickListener(v->showHome());header.addView(back);pageTitle=text("VEDA TV",23,PURPLE,true);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,-2,1);header.addView(pageTitle,tlp);TextView add=text("＋ Добавить канал",13,WHITE,true);add.setPadding(dp(10),dp(10),dp(10),dp(10));add.setBackground(round(0xFF49336A,10));add.setOnClickListener(v->addChannelDialog());header.addView(add);root.addView(header);
        ScrollView cs=new ScrollView(this);cs.setHorizontalScrollBarEnabled(false);categoryRow=new LinearLayout(this);cs.addView(categoryRow);LinearLayout.LayoutParams cslp=new LinearLayout.LayoutParams(-1,dp(48));cslp.topMargin=dp(8);root.addView(cs,cslp);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,0,1);blp.topMargin=dp(8);root.addView(body,blp);
        ScrollView listScroll=new ScrollView(this);channelList=new LinearLayout(this);channelList.setOrientation(LinearLayout.VERTICAL);listScroll.addView(channelList);body.addView(listScroll,new LinearLayout.LayoutParams(dp(250),-1));playerFrame=new FrameLayout(this);playerFrame.setBackground(round(PANEL,16));LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(0,-1,1);plp.leftMargin=dp(10);body.addView(playerFrame,plp);videoView=new VideoView(this);playerFrame.addView(videoView,new FrameLayout.LayoutParams(-1,-1));status=text("Выберите канал для просмотра",15,WHITE,false);status.setGravity(Gravity.CENTER);status.setPadding(dp(15),dp(15),dp(15),dp(15));playerFrame.addView(status,new FrameLayout.LayoutParams(-1,-1));videoView.setOnPreparedListener(mp->{status.setVisibility(View.GONE);videoView.start();});videoView.setOnErrorListener((mp,w,e)->{status.setVisibility(View.VISIBLE);status.setText("Не удалось запустить канал. Проверьте ссылку или выберите другой канал.");return true;});setContentView(root);rebuildCategories();renderChannels();}

    private LinearLayout base(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setBackgroundColor(BG);r.setPadding(dp(16),dp(10),dp(16),dp(12));return r;}
    private Button bigButton(String title,String subtitle){Button b=new Button(this);b.setText(title+"\n"+subtitle);b.setTextColor(WHITE);b.setTextSize(17);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setBackground(round(0xFF49336A,16));b.setMinHeight(dp(82));return b;}
    private LinearLayout.LayoutParams buttonLp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(82));p.leftMargin=dp(8);p.rightMargin=dp(8);return p;}
    private void addChannelDialog(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Название канала");box.addView(name);EditText url=new EditText(this);url.setSingleLine(true);url.setHint("https://... (ссылка на поток)");url.setInputType( android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);box.addView(url);EditText cat=new EditText(this);cat.setSingleLine(true);cat.setHint("Категория (например, Новости)");cat.setText("Армянские");box.addView(cat);new AlertDialog.Builder(this).setTitle("Добавить канал").setView(box).setNegativeButton("Отмена",(d,w)->{}).setPositiveButton("Сохранить",(d,w)->{String n=name.getText().toString().trim(),u=url.getText().toString().trim(),c=cat.getText().toString().trim();if(n.isEmpty()||!u.matches("(?i)^https://.+")){new AlertDialog.Builder(this).setMessage("Введите название и корректную HTTPS-ссылку.").setPositiveButton("OK",null).show();return;}if(c.isEmpty())c="Другие";Channel ch=new Channel(n,c,u);channels.add(ch);saveUserChannel(ch);Toast.makeText(this,"Канал сохранён",Toast.LENGTH_SHORT).show();if(tvPage){rebuildCategories();renderChannels();}else showHome();}).show();}

    private void rebuildCategories(){categoryRow.removeAllViews();LinkedHashSet<String> cats=new LinkedHashSet<>();cats.add("Все");for(Channel c:channels)cats.add(c.category);for(String cat:cats){TextView chip=text(cat,12,WHITE,true);chip.setPadding(dp(12),dp(8),dp(12),dp(8));chip.setFocusable(true);chip.setBackground(round(cat.equals(selectedCategory)?0xFF6846A0:PANEL,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.rightMargin=dp(6);categoryRow.addView(chip,lp);chip.setOnClickListener(v->{selectedCategory=cat;rebuildCategories();renderChannels();});}}
    private void renderChannels(){channelList.removeAllViews();int shown=0;for(int i=0;i<channels.size();i++){Channel c=channels.get(i);if(!selectedCategory.equals("Все")&&!selectedCategory.equals(c.category))continue;shown++;TextView b=text(c.name,13,WHITE,true);b.setPadding(dp(11),dp(12),dp(10),dp(12));b.setFocusable(true);b.setBackground(round(PANEL,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(7);channelList.addView(b,lp);final int ix=i;b.setOnClickListener(v->play(ix));b.setOnFocusChangeListener((v,f)->b.setBackground(round(f?0xFF49336A:PANEL,12)));}if(shown==0)channelList.addView(text("В этой категории каналов нет",13,WHITE,false));pageTitle.setText("VEDA TV • "+shown+" каналов");}
    private void play(int i){Channel c=channels.get(i);status.setVisibility(View.VISIBLE);status.setText("Загрузка: "+c.name);videoView.setVideoURI(Uri.parse(c.url));videoView.requestFocus();}
    private TextView text(String v,int s,int c,boolean bold){TextView t=new TextView(this);t.setText(v);t.setTextSize(s);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onBackPressed(){if(tvPage)showHome();else super.onBackPressed();}
}
