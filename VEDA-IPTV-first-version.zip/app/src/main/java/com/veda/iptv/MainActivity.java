package com.veda.iptv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.content.pm.ActivityInfo;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import android.widget.*;
import android.net.Uri;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.ui.PlayerView;
import android.content.SharedPreferences;
import java.io.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(16,11,28), PANEL=Color.rgb(31,23,49), PURPLE=Color.rgb(179,136,255), WHITE=Color.rgb(248,246,255);
    private LinearLayout root, channelList, categoryRow, body;
    private FrameLayout playerFrame;
    private View channelListContainer;
    private PlayerView playerView;
    private ExoPlayer exoPlayer;
    private TextView status, pageTitle;
    private TextView archiveButton, rotateButton;
    private Channel currentChannel;
    private boolean landscapePlayback=false;
    private final ArrayList<Channel> channels=new ArrayList<>();
    private String selectedCategory="Все";
    private boolean tvPage=false;
    static class Channel { String name, category, url, catchupSource, catchupMode; int archiveDays; Channel(String n,String c,String u){this(n,c,u,0,null,null);} Channel(String n,String c,String u,int days){this(n,c,u,days,null,null);} Channel(String n,String c,String u,int days,String source,String mode){name=n;category=c;url=u;archiveDays=days;catchupSource=source;catchupMode=mode;} }

    @Override public void onCreate(Bundle b){super.onCreate(b); setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN); loadBundledChannels(); loadUserChannels(); showHome();}

    private void loadBundledChannels(){
        try(BufferedReader br=new BufferedReader(new InputStreamReader(getAssets().open("armenian_channels.m3u8"),"UTF-8"))){
            String line,name=null,catchupSource=null,catchupMode=null; int days=0; while((line=br.readLine())!=null){line=line.trim(); if(line.startsWith("#EXTINF")){int comma=line.lastIndexOf(',');name=comma>=0?line.substring(comma+1).trim():"Телеканал";Matcher m=Pattern.compile("tvg-rec=\"(\\d+)\"").matcher(line);days=m.find()?Integer.parseInt(m.group(1)):0;Matcher cs=Pattern.compile("catchup-source=\"([^\"]*)\"").matcher(line);catchupSource=cs.find()?cs.group(1):null;Matcher cm=Pattern.compile("catchup=\"([^\"]*)\"").matcher(line);catchupMode=cm.find()?cm.group(1):null;} else if(!line.isEmpty()&&!line.startsWith("#")&&name!=null){if(line.startsWith("http://")||line.startsWith("https://"))channels.add(new Channel(name,categoryFor(name),line,days,catchupSource,catchupMode));name=null;days=0;catchupSource=null;catchupMode=null;}}
        }catch(Exception ignored){}
    }
    private String categoryFor(String n){String s=n.toLowerCase(Locale.ROOT);
        if(has(s,"news","news","azatutyun","24 news","lurer","новост"))return "Новости";
        if(has(s,"sport","football","fight","sport","матч"))return "Спорт";
        if(has(s,"music","muz","music","radio","музык"))return "Музыка";
        if(has(s,"kino","cinema","cineman","film","movie","кино","фильм"))return "Фильмы";
        if(has(s,"cartoon","kids","baby","junior","детск","мульт"))return "Детские";
        if(has(s,"h1","armenia tv","atv","shant","kentron","armnews","dar 21","yerkir","hay tv"))return "Армянские";
        return "Армянские";
    }
    private boolean has(String s,String... terms){for(String t:terms)if(s.contains(t))return true;return false;}
    private void loadUserChannels(){SharedPreferences p=getSharedPreferences("user_channels",MODE_PRIVATE);String raw=p.getString("items","");for(String row:raw.split("\\n")){String[] a=row.split("\\|",3);if(a.length==3&&!a[2].trim().isEmpty())channels.add(new Channel(a[0],a[1],a[2]));}}
    private void saveUserChannel(Channel c){SharedPreferences p=getSharedPreferences("user_channels",MODE_PRIVATE);String old=p.getString("items","");p.edit().putString("items",old+(old.isEmpty()?"":"\n")+c.name.replace("|"," ")+"|"+c.category.replace("|"," ")+"|"+c.url).apply();}

    private void showHome(){if(tvPage)releasePlayer();tvPage=false;root=base();LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(Gravity.CENTER);content.setPadding(dp(22),dp(20),dp(22),dp(20));root.addView(content,new LinearLayout.LayoutParams(-1,0,1));TextView logo=text("VEDA IPTV",30,PURPLE,true);logo.setGravity(Gravity.CENTER);content.addView(logo);TextView sub=text("Армянское телевидение",15,0xFFBDB5CE,false);sub.setGravity(Gravity.CENTER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.bottomMargin=dp(30);content.addView(sub,sp);
        Button tv=bigButton("▶   VEDA TV","Открыть телеканалы");content.addView(tv,buttonLp());tv.setOnClickListener(v->showTv());Button add=bigButton("＋   Добавить канал","Добавить HTTPS-ссылку вручную");LinearLayout.LayoutParams ap=buttonLp();ap.topMargin=dp(14);content.addView(add,ap);add.setOnClickListener(v->addChannelDialog());TextView foot=text("Каналов в каталоге: "+channels.size(),12,0xFF9288A7,false);foot.setGravity(Gravity.CENTER);content.addView(foot);setContentView(root);}

    private void showTv(){tvPage=true;root=base();LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView back=text("‹  Назад",15,WHITE,true);back.setPadding(dp(8),dp(10),dp(14),dp(10));back.setOnClickListener(v->showHome());header.addView(back);pageTitle=text("VEDA TV",23,PURPLE,true);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,-2,1);header.addView(pageTitle,tlp);TextView add=text("＋ Добавить канал",13,WHITE,true);add.setPadding(dp(10),dp(10),dp(10),dp(10));add.setBackground(round(0xFF49336A,10));add.setOnClickListener(v->addChannelDialog());header.addView(add);root.addView(header);
        ScrollView cs=new ScrollView(this);cs.setHorizontalScrollBarEnabled(false);categoryRow=new LinearLayout(this);cs.addView(categoryRow);LinearLayout.LayoutParams cslp=new LinearLayout.LayoutParams(-1,dp(48));cslp.topMargin=dp(8);root.addView(cs,cslp);
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,0,1);blp.topMargin=dp(8);root.addView(body,blp);
        ScrollView listScroll=new ScrollView(this);channelListContainer=listScroll;channelList=new LinearLayout(this);channelList.setOrientation(LinearLayout.VERTICAL);listScroll.addView(channelList);body.addView(listScroll,new LinearLayout.LayoutParams(-1,0,1));playerFrame=new FrameLayout(this);playerFrame.setBackground(round(PANEL,16));LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(-1,dp(220));plp.topMargin=dp(8);body.addView(playerFrame,plp);playerView=new PlayerView(this);playerView.setUseController(false);playerFrame.addView(playerView,new FrameLayout.LayoutParams(-1,-1));status=text("Выберите канал для просмотра",15,WHITE,false);status.setGravity(Gravity.CENTER);status.setPadding(dp(15),dp(15),dp(15),dp(15));playerFrame.addView(status,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.RIGHT|Gravity.TOP);controls.setOrientation(LinearLayout.HORIZONTAL);
        rotateButton=text("⛶ Повернуть",12,WHITE,true);rotateButton.setPadding(dp(10),dp(8),dp(10),dp(8));rotateButton.setBackground(round(0xFF49336A,10));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-2,-2);rlp.setMargins(dp(4),dp(4),dp(4),dp(4));controls.addView(rotateButton,rlp);rotateButton.setOnClickListener(v->toggleOrientation());
        archiveButton=text("◷ Архив",12,WHITE,true);archiveButton.setPadding(dp(10),dp(8),dp(10),dp(8));archiveButton.setBackground(round(0xFF49336A,10));archiveButton.setVisibility(View.GONE);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-2,-2);alp.setMargins(dp(4),dp(4),dp(8),dp(4));controls.addView(archiveButton,alp);archiveButton.setOnClickListener(v->showArchive());playerFrame.addView(controls,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP|Gravity.RIGHT));
        initPlayer();setContentView(root);rebuildCategories();renderChannels();}

    private void initPlayer(){
        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
            .setUserAgent("VEDA IPTV Android")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000);
        exoPlayer = new ExoPlayer.Builder(this)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory))
            .build();
        playerView.setPlayer(exoPlayer);
        exoPlayer.addListener(new Player.Listener(){
            @Override public void onPlaybackStateChanged(int state){
                if(state==Player.STATE_READY){status.setVisibility(View.GONE);}
                else if(state==Player.STATE_BUFFERING){status.setVisibility(View.VISIBLE);status.setText("Загрузка потока…");}
            }
            @Override public void onPlayerError(PlaybackException error){
                status.setVisibility(View.VISIBLE);
                status.setText("Не удалось запустить канал. Проверьте доступность потока или попробуйте другой канал.");
            }
        });
    }
    private void playUrl(String url){
        if(exoPlayer==null) initPlayer();
        try{
            Uri uri=Uri.parse(url.trim());
            MediaItem.Builder item=new MediaItem.Builder().setUri(uri);
            String path=uri.getPath()==null?"":uri.getPath().toLowerCase(Locale.ROOT);
            if(path.endsWith(".m3u8") || path.endsWith(".m3u")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
            exoPlayer.setMediaItem(item.build());
            exoPlayer.prepare();
            exoPlayer.play();
            playerView.requestFocus();
        }catch(Exception e){status.setVisibility(View.VISIBLE);status.setText("Некорректная ссылка на поток.");}
    }
    private void releasePlayer(){if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;}if(playerView!=null)playerView.setPlayer(null);}
    @Override protected void onDestroy(){releasePlayer();super.onDestroy();}

    private LinearLayout base(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setBackgroundColor(BG);r.setPadding(dp(16),dp(10),dp(16),dp(12));return r;}
    private Button bigButton(String title,String subtitle){Button b=new Button(this);b.setText(title+"\n"+subtitle);b.setTextColor(WHITE);b.setTextSize(17);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setBackground(round(0xFF49336A,16));b.setMinHeight(dp(82));return b;}
    private LinearLayout.LayoutParams buttonLp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(82));p.leftMargin=dp(8);p.rightMargin=dp(8);return p;}
    private void addChannelDialog(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Название канала");box.addView(name);EditText url=new EditText(this);url.setSingleLine(true);url.setHint("https://... (ссылка на поток)");url.setInputType( android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);box.addView(url);EditText cat=new EditText(this);cat.setSingleLine(true);cat.setHint("Категория (например, Новости)");cat.setText("Армянские");box.addView(cat);new AlertDialog.Builder(this).setTitle("Добавить канал").setView(box).setNegativeButton("Отмена",(d,w)->{}).setPositiveButton("Сохранить",(d,w)->{String n=name.getText().toString().trim(),u=url.getText().toString().trim(),c=cat.getText().toString().trim();if(n.isEmpty()||!u.matches("(?i)^https://.+")){new AlertDialog.Builder(this).setMessage("Введите название и корректную HTTPS-ссылку.").setPositiveButton("OK",null).show();return;}if(c.isEmpty())c="Другие";Channel ch=new Channel(n,c,u);channels.add(ch);saveUserChannel(ch);Toast.makeText(this,"Канал сохранён",Toast.LENGTH_SHORT).show();if(tvPage){rebuildCategories();renderChannels();}else showHome();}).show();}

    private void rebuildCategories(){categoryRow.removeAllViews();LinkedHashSet<String> cats=new LinkedHashSet<>();cats.add("Все");for(Channel c:channels)cats.add(c.category);for(String cat:cats){TextView chip=text(cat,12,WHITE,true);chip.setPadding(dp(12),dp(8),dp(12),dp(8));chip.setFocusable(true);chip.setBackground(round(cat.equals(selectedCategory)?0xFF6846A0:PANEL,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.rightMargin=dp(6);categoryRow.addView(chip,lp);chip.setOnClickListener(v->{selectedCategory=cat;rebuildCategories();renderChannels();});}}
    private void renderChannels(){channelList.removeAllViews();int shown=0;for(int i=0;i<channels.size();i++){Channel c=channels.get(i);if(!selectedCategory.equals("Все")&&!selectedCategory.equals(c.category))continue;shown++;TextView b=text(c.name,13,WHITE,true);b.setPadding(dp(11),dp(12),dp(10),dp(12));b.setFocusable(true);b.setBackground(round(PANEL,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(7);channelList.addView(b,lp);final int ix=i;b.setOnClickListener(v->play(ix));b.setOnFocusChangeListener((v,f)->b.setBackground(round(f?0xFF49336A:PANEL,12)));}if(shown==0)channelList.addView(text("В этой категории каналов нет",13,WHITE,false));pageTitle.setText("VEDA TV • "+shown+" каналов");}
    private void play(int i){Channel c=channels.get(i);currentChannel=c;status.setVisibility(View.VISIBLE);status.setText("Загрузка: "+c.name);archiveButton.setVisibility(c.archiveDays>0?View.VISIBLE:View.GONE);archiveButton.setText("◷ Архив · "+c.archiveDays+" дн.");playUrl(c.url);}
    private void toggleOrientation(){
        landscapePlayback=!landscapePlayback;
        setRequestedOrientation(landscapePlayback?ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        rotateButton.setText(landscapePlayback?"▣ Вертикально":"⛶ Полный экран");
        if(landscapePlayback){
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            root.setPadding(0,0,0,0);
            for(int i=0;i<root.getChildCount();i++){View child=root.getChildAt(i);if(child!=body)child.setVisibility(View.GONE);}
            if(body!=null){LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)body.getLayoutParams();lp.height=0;lp.weight=1;lp.topMargin=0;body.setLayoutParams(lp);}
            if(channelListContainer!=null)channelListContainer.setVisibility(View.GONE);
            if(playerFrame!=null){LinearLayout.LayoutParams pp=(LinearLayout.LayoutParams)playerFrame.getLayoutParams();pp.height=0;pp.weight=1;pp.topMargin=0;playerFrame.setLayoutParams(pp);playerFrame.setBackgroundColor(Color.BLACK);}
            if(rotateButton!=null)rotateButton.setText("▣ Вертикально");
            if(archiveButton!=null)archiveButton.setVisibility(currentChannel!=null&&currentChannel.archiveDays>0?View.VISIBLE:View.GONE);
        }else{
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
            root.setPadding(dp(16),dp(10),dp(16),dp(12));
            for(int i=0;i<root.getChildCount();i++)root.getChildAt(i).setVisibility(View.VISIBLE);
            if(body!=null){LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)body.getLayoutParams();lp.height=0;lp.weight=1;lp.topMargin=dp(8);body.setLayoutParams(lp);}
            if(channelListContainer!=null)channelListContainer.setVisibility(View.VISIBLE);
            if(playerFrame!=null){LinearLayout.LayoutParams pp=(LinearLayout.LayoutParams)playerFrame.getLayoutParams();pp.height=dp(220);pp.weight=0;pp.topMargin=dp(8);playerFrame.setLayoutParams(pp);playerFrame.setBackground(round(PANEL,16));}
            if(rotateButton!=null)rotateButton.setText("⛶ Полный экран");
        }
    }
    private void showArchive(){
        if(currentChannel==null){new AlertDialog.Builder(this).setTitle("Архив передач").setMessage("Сначала выберите канал.").setPositiveButton("OK",null).show();return;}
        if(currentChannel.archiveDays<=0){new AlertDialog.Builder(this).setTitle("Архив передач").setMessage("Для этого канала в плейлисте не указана доступность архива.").setPositiveButton("OK",null).show();return;}
        if(currentChannel.catchupSource==null || currentChannel.catchupSource.trim().isEmpty()){
            new AlertDialog.Builder(this).setTitle("Архив: "+currentChannel.name).setMessage("В плейлисте заявлен архив на "+currentChannel.archiveDays+" дн., но нет catchup-source или шаблона архивного URL. Televizo может определять формат автоматически, однако эта M3U не сообщает приложению, как запросить запись. Нельзя безопасно угадать адрес архива.").setPositiveButton("Выбрать дату",(d,w)->pickArchiveDate()).setNegativeButton("Закрыть",null).show();return;
        }
        pickArchiveDate();
    }
    private void pickArchiveDate(){
        Calendar now=Calendar.getInstance();Calendar min=(Calendar)now.clone();min.add(Calendar.DAY_OF_YEAR,-Math.max(1,currentChannel.archiveDays));
        DatePickerDialog dpd=new DatePickerDialog(this,(view,year,month,day)->{
            new TimePickerDialog(this,(tv,hour,minute)->{
                Calendar selected=Calendar.getInstance();selected.set(year,month,day,hour,minute,0);long start=selected.getTimeInMillis()/1000L;String url=buildCatchupUrl(currentChannel,start,1800);
                if(url==null){new AlertDialog.Builder(this).setTitle("Архив недоступен").setMessage("Не удалось построить URL архива из данных плейлиста. Нужен формат архива провайдера.").setPositiveButton("OK",null).show();return;}
                status.setVisibility(View.VISIBLE);status.setText("Загрузка архива: "+currentChannel.name);playUrl(url);
            },now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true).show();
        },now.get(Calendar.YEAR),now.get(Calendar.MONTH),now.get(Calendar.DAY_OF_MONTH));
        dpd.getDatePicker().setMaxDate(now.getTimeInMillis());dpd.getDatePicker().setMinDate(min.getTimeInMillis());dpd.show();
    }
    private String buildCatchupUrl(Channel c,long startSeconds,int durationSeconds){
        if(c.catchupSource==null||c.catchupSource.trim().isEmpty())return null;
        String start=String.valueOf(startSeconds),duration=String.valueOf(durationSeconds);String iso=new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date(startSeconds*1000L));String fmt=new java.text.SimpleDateFormat("yyyy-MM-dd:HH-mm",Locale.US).format(new Date(startSeconds*1000L));
        String out=c.catchupSource.replace("${start}",start).replace("${timestamp}",start).replace("${duration}",duration).replace("${offset}",duration).replace("${utc}",start).replace("${date}",fmt).replace("${start_iso}",iso).replace("{utc}",start).replace("{start}",start).replace("{duration}",duration).replace("{offset}",duration).replace("{Y}",new java.text.SimpleDateFormat("yyyy",Locale.US).format(new Date(startSeconds*1000L))).replace("{m}",new java.text.SimpleDateFormat("MM",Locale.US).format(new Date(startSeconds*1000L))).replace("{d}",new java.text.SimpleDateFormat("dd",Locale.US).format(new Date(startSeconds*1000L))).replace("{H}",new java.text.SimpleDateFormat("HH",Locale.US).format(new Date(startSeconds*1000L))).replace("{M}",new java.text.SimpleDateFormat("mm",Locale.US).format(new Date(startSeconds*1000L)));
        if(!out.startsWith("http://")&&!out.startsWith("https://"))return null;return out;
    }
    private TextView text(String v,int s,int c,boolean bold){TextView t=new TextView(this);t.setText(v);t.setTextSize(s);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onBackPressed(){if(tvPage)showHome();else super.onBackPressed();}
}
