package com.veda.iptv;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.KeyEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.VideoView;
import android.net.Uri;
import android.content.Intent;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int PICK_PLAYLIST = 4101;
    private final int BG = Color.rgb(16,11,28);
    private final int PANEL = Color.rgb(31,23,49);
    private final int PURPLE = Color.rgb(179,136,255);
    private final int WHITE = Color.rgb(248,246,255);
    private LinearLayout root, channelList, categoryRow;
    private FrameLayout playerFrame;
    private VideoView videoView;
    private TextView status, playlistStatus;
    private final ArrayList<Channel> allChannels = new ArrayList<>();
    private String selectedCategory = "Все";
    private String currentPlaylistName = "Демо-каналы";

    static class Channel {
        String name, category, url, logo;
        int archiveDays;
        Channel(String n, String c, String u, String l, int days) {
            name=n; category=c; url=u; logo=l; archiveDays=days;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        loadDemoStreams();
        buildUi();
    }

    private void loadDemoStreams() {
        allChannels.clear();
        allChannels.add(new Channel("Демо-поток 1", "Демо",
            "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", "", 0));
        allChannels.add(new Channel("Демо-поток 2", "Демо",
            "https://streams.bitmovin.com/sintel/index.m3u8", "", 0));
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(16), dp(10), dp(16), dp(10));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("VEDA IPTV", 25, PURPLE, true);
        header.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView importBtn = text("＋ ДОБАВИТЬ ПЛЕЙЛИСТ", 12, WHITE, true);
        importBtn.setFocusable(true);
        importBtn.setPadding(dp(12), dp(10), dp(12), dp(10));
        importBtn.setBackground(round(0xFF49336A, 10));
        importBtn.setOnClickListener(v -> openPlaylistPicker());
        header.addView(importBtn);
        root.addView(header);

        playlistStatus = text("Выберите демо-канал или импортируйте M3U-файл", 12, 0xFFBDB5CE, false);
        LinearLayout.LayoutParams pslp = new LinearLayout.LayoutParams(-1, -2);
        pslp.topMargin = dp(4);
        pslp.bottomMargin = dp(8);
        root.addView(playlistStatus, pslp);

        ScrollView catScroll = new ScrollView(this);
        catScroll.setHorizontalScrollBarEnabled(false);
        categoryRow = new LinearLayout(this);
        categoryRow.setOrientation(LinearLayout.HORIZONTAL);
        catScroll.addView(categoryRow);
        LinearLayout.LayoutParams cslp = new LinearLayout.LayoutParams(-1, dp(44));
        cslp.bottomMargin = dp(8);
        root.addView(catScroll, cslp);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setPadding(0, 0, dp(12), 0);
        body.addView(left, new LinearLayout.LayoutParams(dp(220), -1));
        left.addView(text("ТЕЛЕКАНАЛЫ", 15, WHITE, true));

        ScrollView scroll = new ScrollView(this);
        channelList = new LinearLayout(this);
        channelList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(channelList);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, 0, 1);
        slp.topMargin = dp(8);
        left.addView(scroll, slp);

        playerFrame = new FrameLayout(this);
        playerFrame.setBackground(round(PANEL, 18));
        body.addView(playerFrame, new LinearLayout.LayoutParams(0, -1, 1));
        videoView = new VideoView(this);
        playerFrame.addView(videoView, new FrameLayout.LayoutParams(-1, -1));
        status = text("Выберите канал для просмотра", 15, WHITE, false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(18), dp(18), dp(18), dp(18));
        playerFrame.addView(status, new FrameLayout.LayoutParams(-1, -1));
        videoView.setOnPreparedListener(mp -> {
            status.setVisibility(View.GONE);
            videoView.start();
        });
        videoView.setOnErrorListener((mp, what, extra) -> {
            status.setVisibility(View.VISIBLE);
            status.setText("Не удалось запустить поток. Проверьте ссылку или попробуйте другой канал.");
            return true;
        });

        TextView footer = text("M3U • HLS • Android / Android TV", 11, 0xFF9288A7, false);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = dp(7);
        root.addView(footer, flp);
        setContentView(root);
        rebuildCategories();
        renderChannels();
    }

    private void openPlaylistPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/x-mpegurl", "application/vnd.apple.mpegurl", "text/plain", "application/octet-stream"});
        startActivityForResult(intent, PICK_PLAYLIST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_PLAYLIST || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            ArrayList<Channel> parsed = parseM3U(uri);
            if (parsed.isEmpty()) {
                playlistStatus.setText("В файле не найдено каналов. Проверьте формат M3U.");
                return;
            }
            allChannels.clear();
            allChannels.addAll(parsed);
            currentPlaylistName = queryName(uri);
            selectedCategory = "Все";
            playlistStatus.setText("Плейлист: " + currentPlaylistName + " • каналов: " + allChannels.size());
            rebuildCategories();
            renderChannels();
        } catch (Exception e) {
            playlistStatus.setText("Не удалось прочитать плейлист. Попробуйте выбрать файл ещё раз.");
        }
    }

    private String queryName(Uri uri) {
        String result = "M3U";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) result = c.getString(i);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private ArrayList<Channel> parseM3U(Uri uri) throws Exception {
        ArrayList<Channel> out = new ArrayList<>();
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            String line, name = null, group = "Другие", logo = "";
            int rec = 0;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("#EXTINF")) {
                    int comma = line.lastIndexOf(',');
                    name = comma >= 0 ? line.substring(comma + 1).trim() : "Без названия";
                    group = attr(line, "group-title", "Другие");
                    logo = attr(line, "tvg-logo", "");
                    String recValue = attr(line, "tvg-rec", "0");
                    try { rec = Integer.parseInt(recValue); } catch (Exception ignored) { rec = 0; }
                    // Do not import adult-category entries into the initial app.
                    String lower = (group + " " + name).toLowerCase(Locale.ROOT);
                    if (lower.contains("взросл") || lower.contains("adult") || lower.contains("xxx")) name = null;
                } else if (!line.isEmpty() && !line.startsWith("#") && name != null) {
                    if (line.startsWith("http://") || line.startsWith("https://")) {
                        out.add(new Channel(name, group, line, logo, rec));
                    }
                    name = null;
                }
            }
        }
        return out;
    }

    private String attr(String line, String key, String fallback) {
        Matcher m = Pattern.compile("(?:^|\\s)" + Pattern.quote(key) + "=\"([^\"]*)\"").matcher(line);
        return m.find() ? m.group(1) : fallback;
    }

    private void rebuildCategories() {
        categoryRow.removeAllViews();
        java.util.LinkedHashSet<String> cats = new java.util.LinkedHashSet<>();
        cats.add("Все");
        for (Channel c : allChannels) cats.add(c.category == null || c.category.isEmpty() ? "Другие" : c.category);
        for (String cat : cats) {
            TextView chip = text(cat, 12, WHITE, true);
            chip.setPadding(dp(12), dp(8), dp(12), dp(8));
            chip.setFocusable(true);
            chip.setBackground(round(cat.equals(selectedCategory) ? 0xFF6846A0 : PANEL, 18));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dp(6);
            categoryRow.addView(chip, lp);
            chip.setOnClickListener(v -> {
                selectedCategory = cat;
                rebuildCategories();
                renderChannels();
            });
        }
    }

    private void renderChannels() {
        channelList.removeAllViews();
        int shown = 0;
        for (int i=0; i<allChannels.size(); i++) {
            Channel c = allChannels.get(i);
            if (!selectedCategory.equals("Все") && !selectedCategory.equals(c.category)) continue;
            shown++;
            String archive = c.archiveDays > 0 ? "  •  АРХИВ " + c.archiveDays + " дн." : "";
            TextView b = text(c.name + archive, 13, WHITE, true);
            b.setPadding(dp(11), dp(12), dp(10), dp(12));
            b.setFocusable(true);
            b.setClickable(true);
            b.setBackground(round(PANEL, 12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(7);
            channelList.addView(b, lp);
            final int index = i;
            b.setOnClickListener(v -> selectChannel(index));
            b.setOnFocusChangeListener((v, hasFocus) -> b.setBackground(round(hasFocus ? 0xFF49336A : PANEL, 12)));
        }
        if (shown == 0) channelList.addView(text("В этой категории каналов нет", 13, WHITE, false));
    }

    private void selectChannel(int index) {
        if (index < 0 || index >= allChannels.size()) return;
        Channel c = allChannels.get(index);
        status.setVisibility(View.VISIBLE);
        String message = "Загрузка: " + c.name;
        if (c.archiveDays > 0) message += "\\nАрхив указан в плейлисте: " + c.archiveDays + " дн.\\nДля просмотра архива нужен поддерживаемый источником формат catch-up.";
        status.setText(message);
        videoView.setVideoURI(Uri.parse(c.url));
        videoView.requestFocus();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
